package com.horis.cloudstreamplugins.entities

data class Source(
    val file: String,
    val label: String,
    val type: String
)
