package com.horis.cloudstreamplugins.entities

data class Tracks(
    val kind: String?,
    val file: String?,
    val label: String?,
)
