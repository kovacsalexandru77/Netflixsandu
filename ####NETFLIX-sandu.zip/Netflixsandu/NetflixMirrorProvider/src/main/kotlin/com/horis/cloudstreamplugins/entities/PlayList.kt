package com.horis.cloudstreamplugins.entities

class PlayList : ArrayList<PlayListItem>()
